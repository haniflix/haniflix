const uploadFile = require("./uploadFile");
const deleteImage = require("./deleteImage");
const getAllimages = require("./getAllimages");

module.exports = {
  uploadFile,
  deleteImage,
  getAllimages,
};

const syncServerMoviesToDatabase = require("./syncServerMoviesToDatabase");

module.exports = {
  syncServerMoviesToDatabase,
};

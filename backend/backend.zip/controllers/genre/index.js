const createGenre = require("./createGenre");
const deleteGenre = require("./deleteGenre");
const getGenres = require("./getGenres");

module.exports = {
  createGenre,
  deleteGenre,
  getGenres,
};
